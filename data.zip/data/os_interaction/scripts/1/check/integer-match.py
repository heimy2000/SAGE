from sys import argv
if int(argv[1]) == int(argv[2]): exit(0)
exit(1)