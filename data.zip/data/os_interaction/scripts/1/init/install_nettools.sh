#!/usr/bin/env bash

apt-get update && apt-get install -y net-tools iproute2 lsof